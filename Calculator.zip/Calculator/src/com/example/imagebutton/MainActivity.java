package com.example.imagebutton;


import android.support.v7.app.ActionBarActivity;
import android.text.TextUtils;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends ActionBarActivity implements OnClickListener {

	ImageButton add,sub, mul,divide,per,sqrt;
	EditText num1,num2;
	TextView result;
	float n1=0,n2=0,r1=0;
	String oper;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		add=(ImageButton) findViewById(R.id.imageButton1);
		sub=(ImageButton) findViewById(R.id.imageButton2);
		mul=(ImageButton) findViewById(R.id.imageButton3);
		divide=(ImageButton) findViewById(R.id.imageButton4);
		per=(ImageButton) findViewById(R.id.imageButton5);
		sqrt=(ImageButton) findViewById(R.id.imageButton6);
		num1=(EditText) findViewById(R.id.editText1);
		num2=(EditText) findViewById(R.id.editText2);
		result=(TextView) findViewById(R.id.textView1);
		
		
		
		add.setOnClickListener(this);
		sub.setOnClickListener(this);
		mul.setOnClickListener(this);
		divide.setOnClickListener(this);
		per.setOnClickListener(this);
		sqrt.setOnClickListener(this);
		
	
	}
	@Override
	public void onClick(View v) {
if(TextUtils.isEmpty(num1.getText().toString())||TextUtils.isEmpty(num2.getText().toString()))	
		{
	return;
		}


 n1=Float.parseFloat(num1.getText().toString());
 n2=Float.parseFloat(num2.getText().toString());
 
 switch (v.getId()) {
case R.id.imageButton1:
	oper="+";
	r1=n1+n2;
	result.setText(n1+""+oper+""+n2+"="+r1);
	
	break;
case R.id.imageButton2 :
	oper="-";
	r1=n1-n2;
	result.setText(n1+""+oper+""+n2+"="+r1);
break;
case R.id.imageButton3:
	oper="*";
	r1=n1*n2;
	result.setText(n1+""+oper+""+n2+"="+r1);
	break;
	case R.id.imageButton4:
		oper="/";
		r1=n1/n2;
		result.setText(n1+""+oper+""+n2+"="+r1);
		break;
		
	case R.id.imageButton5:
		oper="%";
		r1=(n1*(n2/100));
		result.setText(n1+""+oper+""+n2+"="+r1);
		break;
	case R.id.imageButton6:
		oper="sqre";
		r1=(n1*n1);
		result.setText(n1+""+oper+""+n1+"="+r1);
default:
	break;
}

	}
	
	
	
}
