package com.example.fragmentprj;

import android.support.v7.app.ActionBarActivity;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity{ 
	Button f1,f2;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		f1=(Button)findViewById(R.id.buttonF1);
		f2=(Button)findViewById(R.id.buttonF2);
		
	
	}

	public void click(View v)
	{
		Fragment fr;
		
		if(v==findViewById(R.id.buttonF2))
		{
			fr= new F2();
			
		}
		else
		{
			fr= new F1();
		}
		FragmentManager fm= getFragmentManager();
		FragmentTransaction ft=fm.beginTransaction();
		ft.replace(R.id.fragmentrplc, fr);
		ft.commit();

	}
	
	
	

	}
