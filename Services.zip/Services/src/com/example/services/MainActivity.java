package com.example.services;

import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends ActionBarActivity {
 Button strt,stop;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		strt=(Button) findViewById(R.id.buttonStart);
		stop=(Button) findViewById(R.id.buttonStop);
		
		strt.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent start=new Intent(MainActivity.this,Servies_Ms.class);
				startService(start);
				
			}
		});
		stop.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent stop=new Intent(MainActivity.this,Servies_Ms.class);
				stopService(stop);
				
			}
		});
	}

}
